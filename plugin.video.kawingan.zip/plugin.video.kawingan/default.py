import urllib2, urllib, xbmcgui, xbmcplugin, xbmc, re, sys, os, xbmcaddon
import urlresolver
from addon.common.addon import Addon
import requests
s = requests.session() 
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
addon_id='plugin.video.kawingan'
selfAddon = xbmcaddon.Addon(id=addon_id)
addon = Addon(addon_id, sys.argv)
addon_name = selfAddon.getAddonInfo('name')
ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')
ICON = ADDON.getAddonInfo('icon')
FANART = ADDON.getAddonInfo('fanart')
PATH = 'kawingan'
VERSION = ADDON.getAddonInfo('version')
ART = ADDON_PATH + "/resources/icons/"


SRC_WPMO = 'http://watchpinoymoviesonline.info'
SRC_KAPUSO = 'http://www.kapuso.be'
SRC_PLAF = 'http://pacitalaflakes.blogspot.com'
SRC_PHVIDTV = 'http://phvidtv.blogspot.com'
SRC_PBA = 'http://www.sportsnation.info'
SRC_OFWPT = 'http://ofwpinoytambayan.su'

def MENU():
    addDir('[B][COLOR aqua]PELIKULA[/COLOR][/B]','url',2,ART + 'pinoymov.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR red]PINAS TV[/COLOR][/B]',SRC_PHVIDTV,6,ART + 'phvidtv.jpg',FANART,'')
    addDir('[B][COLOR green]KAPAMILYA[/COLOR][/B]',SRC_PLAF + '/search/label/ABS-CBN?m=0',5,ART + 'kapamilya.jpg',FANART,'')
    addDir('[B][COLOR white]KAPUSO[/COLOR][/B]',SRC_KAPUSO + '/search/label/GMA?&max-results=24',5,ART + 'kapusoako.jpg',FANART,'')
    setView('tvshows', 'tvshows-view')

    
def Get_content(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<a class='thumbx' href='(.+?)' title='(.+?)'.+?src='(.+?)'/></a>",re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&amp;#038;','&')
        icon = icon.replace('s72-c/','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,10,icon,FANART,'')
    np = re.compile("<a class='blog-pager-older-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        if 'kapuso' in url:
            icon = ART + 'nextpagekap.jpg'
        if 'pacitalaflakes' in url:
            icon = ART + 'nextpagetamb.jpg'
        addDir('[B][COLOR red]Older Posts>>>[/COLOR][/B]',url,5,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_links(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('<[iI][fF][rR][aA][mM][eE] [sS][rR][cC]="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
        except:pass
        if 'relaxpinas' in url:
            addDir('[B][COLOR white]%s [/COLOR][/B]' %name2,url,11,iconimage,FANART,name)
        else:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    altlinks = re.compile('DM.player.+?"player(.+?)".+?video: "(.+?)"',re.DOTALL).findall(OPEN)
    for name2,url in altlinks:
        addDir('[B][COLOR white]Part %s[/COLOR][/B]' %name2,'http://www.dailymotion.com/embed/video/%s'%url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_links_relaxpinas(name,url):
    OPEN = Open_Url(url)
    xbmc.log('###### URL: %s' % url)
    Regex = re.compile("'http(.+?)'",re.DOTALL).findall(OPEN)
    for url in Regex:
        url = 'http' + url
        xbmc.log('###### URL2: %s' % url)
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
        except:pass
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    altlinks = re.compile('DM.player.+?"player(.+?)".+?video: "(.+?)"',re.DOTALL).findall(OPEN)
    for name2,url in altlinks:
        addDir('[B][COLOR white]Part %s[/COLOR][/B]' %name2,'http://www.dailymotion.com/embed/video/%s'%url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_content_phvidtv(url):
    OPEN = Open_Url(url)
    Regex = re.compile("<h2 class='post-title entry-title'><a href='(.+?)'>(.+?)</a>.+?src=\"(.+?)\"",re.DOTALL).findall(OPEN)
    for url,name,icon in Regex:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#39;','\'').replace('&amp;#038;','&')
        icon = icon.replace('s72-c/','')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,12,icon,FANART,'')
    np = re.compile("<a class='blog-pager-older-link' href='(.+?)'",re.DOTALL).findall(OPEN)
    for url in np:
        if 'kapuso' in url:
            icon = ART + 'nextpagekap.jpg'
        if 'pacitalaflakes' in url:
            icon = ART + 'nextpagetamb.jpg'
        addDir('[B][COLOR red]Older Posts>>>[/COLOR][/B]',url,5,icon,FANART,'')
    xbmc.executebuiltin('Container.SetViewMode(50)')

def Get_links_phvidtv(name,url):
    OPEN = Open_Url(url)
    Regex = re.compile('iframe class="embed-responsive-item" src="(.+?)"',re.DOTALL).findall(OPEN)
    for url in Regex:
        try:
            name2 = url.split('//')[1].replace('www.','')
            name2 = name2.split('/')[0].split('.')[0].title()
        except:pass
        if 'relaxpinas' in url:
            addDir('[B][COLOR white]%s [/COLOR][/B]' %name2,url,11,iconimage,FANART,name)
        else:
            addDir('[B][COLOR white]%s[/COLOR][/B]' %name2,url,100,iconimage,FANART,name)
    altlinks = re.compile('DM.player.+?"player(.+?)".+?video: "(.+?)"',re.DOTALL).findall(OPEN)
    for name2,url in altlinks:
        addDir('[B][COLOR white]Part %s[/COLOR][/B]' %name2,'http://www.dailymotion.com/embed/video/%s'%url,100,iconimage,FANART,name)
    xbmc.executebuiltin('Container.SetViewMode(50)')


###############watchpinoymovies###########

def pinoyonlinemenu():
    addDir('[B][COLOR white]Latest Movies[/COLOR][/B]',SRC_WPMO+'/category/latest/',20,ART + 'latest.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Classic Movies[/COLOR][/B]',SRC_WPMO+'/category/pinoy-classic-movies/',20,ART + 'classic.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Movies by Genre[/COLOR][/B]',SRC_WPMO,21,ART + 'genre.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]All Movies[/COLOR][/B]',SRC_WPMO+'/category/pinoy-movies/',20,ART + 'allmov.jpg',ART + 'fanart2.jpg','')
    addDir('[B][COLOR white]Live Streams[/COLOR][/B]',SRC_WPMO+'/category/live-stream/',22,ART + 'stream.jpg',ART + 'fanart2.jpg','')
    setView('tvshows', 'tvshows-view')
    
def Mov_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('div id="content" role="main">(.+?)<!-- end #content -->',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a class="clip-link".+?href="(.+?)".+?<img src="(.+?)" alt="(.+?)"',re.DOTALL).findall(str(Regex))
    for url,icon,name in Regex2:
        name = name.replace('&#8217;','\'').replace('&#8211;','-').replace('&#039;','\'').replace('&#038;','&').replace('&#8230;','...')
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,100,icon,ART + 'fanart2.jpg','')
    np = re.compile('rel="next".+?href="(.+?)"',re.DOTALL).findall(OPEN)
    for url in np:
        addDir('[B][COLOR red]Next Page>>>[/COLOR][/B]',url,20,ART + 'n_p.jpg',ART + 'fanart2.jpg','')
    setView('tvshows', 'default-view')    

def live_Menu(url):
    OPEN = Open_Url(url)
    Regex = re.compile('class="item-video".+?href="(.+?)".+?<img src="(.+?)"',re.DOTALL).findall(OPEN)
    for url,icon in Regex:
        if 'http' not in icon:
            icon = 'http:' + icon
        name = url.split('//')[1]
        name = name.split('/')[1].replace('-',' ').replace('live streaming','(Stream) ').title()
        addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,80,icon,ART + 'fanart2.jpg','')
    setView('tvshows', 'default-view')     

def cats_mov(url):
    OPEN = Open_Url(url)
    Regex = re.compile('<ul class="sub-menu">(.+?)<!-- end #main-nav -->',re.DOTALL).findall(OPEN)
    Regex2 = re.compile('<a href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(Regex))
    for url,name in Regex2:
        if 'Ghost Fighter' not in name:
            if 'Slam Dunk' not in name:
                if 'Pinoy Classic' not in name:
                    if 'Latest' not in name:
                        if 'Live Stream' not in name:
                            addDir('[B][COLOR white]%s[/COLOR][/B]' %name,url,20,ART + 'genre.jpg',ART + 'fanart2.jpg','')   

def res_live(url):
    OPEN = Open_Url(url)
    if '//livestream01' in OPEN:
       url = re.compile('var video="(.+?)"',re.DOTALL).findall(OPEN)[0]
    elif 'file: ' in OPEN:
        try:
            url = re.compile('file: "(.+?)"',re.DOTALL).findall(OPEN)[0]
        except:
            url = re.compile("file: '(.+?)'",re.DOTALL).findall(OPEN)[0]
    else:
        url = re.compile('<iframe.+?src="(.+?)"',re.DOTALL).findall(OPEN)[0]
        url = url.replace('?autoplay=1&wmode=opaque&rel=0&showinfo=0&modestbranding=0','')
    url1 = urlresolver.resolve(url)
    if url1:
        try:
            liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
            liz.setInfo(type='Video', infoLabels={'Title':description})
            liz.setProperty("IsPlayable","true")
            liz.setPath(url1)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        except: pass
    else:
        liz = xbmcgui.ListItem(name, iconImage='DefaultVideo.png', thumbnailImage=iconimage)
        liz.setInfo(type='Video', infoLabels={'Title':description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz) 
        




###################################   
def RESOLVE(url):
    #print '>>>>>>>>>>>>>>>>>>>>>>' + url + '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<'
    try:
        if 'speedvid.net' in url:
#            OPEN = Open_Url(url)
#            link = re.compile('primary\|8777\|.+?primary\|(.+?)\|(.+?)\|.+?image\|mp4\|(.+?)\|',re.DOTALL).findall(OPEN)
#            for port,server,hash in link:
#                url = 'http://'+ server +'.speedvid.net:'+port+'/'+hash+'/v.mp4'
            stream_url=url
        elif 'sendvid.com' in url:
            stream_url=url
        elif 'watchpinoymoviesonline.info' in url:
            OPEN = Open_Url(url)
            url = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(OPEN)[0]
            stream_url = urlresolver.resolve(url)
        else:
            stream_url = urlresolver.resolve(url)
        liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo(type="Video", infoLabels={"Title": description})
        liz.setProperty("IsPlayable","true")
        liz.setPath(stream_url)
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR cornflowerblue]Sorry[/COLOR],[COLOR red]Link Unavailable[/COLOR] ,3000)") 

def get_params():
    param=[]
    paramstring=sys.argv[2]
    if len(paramstring)>=2:
        params=sys.argv[2]
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    return param

def Open_Url(url):
    headers = {}
    headers['User-Agent'] = User_Agent
    link = s.get(url, headers=headers).text
    link = link.encode('ascii', 'ignore')
    return link.replace('\n', '').replace('\t', '').replace('\r', '')

    
    
def addDir(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&description="+urllib.quote_plus(description)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={"Title": name,"Plot":description})
    liz.setProperty('fanart_image', fanart)
    if mode==100 or mode==80 or mode==50 or mode==40 or mode==101 or mode==102:
        liz.setProperty("IsPlayable","true")
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    else:
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    return ok

def setView(content, viewType):
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.get_setting('auto-view') == 'true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
    
params=get_params()
url=None
name=None
mode=None
iconimage=None
description=None




try:
    url=urllib.unquote_plus(params["url"])
except:
    pass
try:
    name=urllib.unquote_plus(params["name"])
except:
    pass
try:
    iconimage=urllib.unquote_plus(params["iconimage"])
except:
    pass
try:
    mode=int(params["mode"])
except:
    pass
try:
    description=urllib.unquote_plus(params["description"])
except:
    pass

if mode==None or url==None or len(url)<1 : MENU()
elif mode == 2 : pinoyonlinemenu()
elif mode == 3 : moviechannel()
elif mode == 5 : Get_content(url) 
elif mode == 6 : Get_content_phvidtv(url) 
elif mode == 10 : Get_links(name,url)
elif mode == 11 : Get_links_relaxpinas(name,url)
elif mode == 12 : Get_links_phvidtv(name,url)
elif mode == 20 : Mov_Menu(url)
elif mode == 21 : cats_mov(url)
elif mode == 22 : live_Menu(url)
elif mode == 50 : RES_mov(url) 
elif mode == 80 : res_live(url)
elif mode ==100: RESOLVE(url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))

















